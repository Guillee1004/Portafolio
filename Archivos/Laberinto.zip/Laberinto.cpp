#include <conio.h>
#include <windows.h>
#include <stdio.h>

#define FIL  9 // cantidad de filas    del laberinto; constantes en MAYUSCULAS
#define COL 12 // cantidad de columnas del laberinto

#define LX  35 // desplazamiento coordenada x (columna) situar laberinto en pant
#define LY   7 // desplazamiento coordenada y (fila)    situar laberinto en pant

void gotoxy(short x, short y) 
{
  HANDLE cur = GetStdHandle(STD_OUTPUT_HANDLE); // Obtener handle de la consola
  COORD pos  = {x, y};                          // Crear estructura COORD con coordenadas x e y
  SetConsoleCursorPosition(cur, pos);           // Establecer posición cursor en consola
}
void hidecursor()
{
  HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
  CONSOLE_CURSOR_INFO info;
  info.dwSize   = 100;
  info.bVisible = FALSE;
  SetConsoleCursorInfo(consoleHandle, &info);
}
void showcursor()
{
  HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
  CONSOLE_CURSOR_INFO info;
  info.dwSize   = 100;
  info.bVisible = TRUE;
  SetConsoleCursorInfo(consoleHandle, &info);
}

int main(void)
{
  //textbackground(15); // color de fondo de toda la pantalla: gris
  //clrscr();
  hidecursor();
  gotoxy(30,3);   //fila 3, columna 30
  //textcolor(4);
  printf("EL LABERINTO TENEBROSO\n");
  gotoxy(20,4);
  printf("W=Subir A=Izquierda S=Bajar D=Derecha");

  int lab[FIL+1][COL];         // matriz laberinto EN MEMORIA INTERNA DE 10x12
  int laberinto(int l[][COL]); // funcion para dibujar laberinto EN PANTALLA
  int mover(int l[][COL]);     // moverse en el laberinto EN PANTALLA

  laberinto(lab);  //llama a dibujar el laberinto
  mover(lab);      //llama a moverse por el laberinto
  getch();         //para detener al final del programa y ver resultado
  showcursor();
  return 0;
}

int laberinto(int l[][COL]) //dibujo del laberinto
{
  int i,j;
  //textcolor(4); //color de lugar NO vacio: rojo

  for (i=1;i<=FIL;i++)     //ciclo PARA, para manejar las filas    i
    for (j=1;j<=COL;j++)   //ciclo PARA, para manejar las columnas j
     {
       l[i][j]=0;     //0: lugar vacio, donde puede desplazarse
                      //4: lugar NO vacio, donde NO puede desplazarse

       //lugares no vacios, donde NO puede desplazarse, se esta poniendo 4
       if((i==1 && j!=2)||(i==FIL && j!=COL-1)||(j==1||j==COL))    l[i][j]=4;
       if (i==3 && j!=COL-2)   l[i][j]=4;
       if (i==5 && j!=2)       l[i][j]=4;
       if (i==7 && j!=COL-2)   l[i][j]=4;
       if (i==8 && j>3 && j<9) l[i][j]=4;

       // l[2][4]=4;  //ojo   // pone traba en el laberinto
       // l[7][3]=0;  //puesto por profesor, camino que no lleva a la meta

       if (l[i][j] == 4)
         {
           gotoxy(LX+j,LY+i);
           printf("\xB0");     //pintar los lugares NO vacios  Û
           l[i][j] = 4;
         }
     }
  return 0;
}

int mover(int l[][COL])
{
  int i=1,j=2, x=i, y=j, c;

  do
  {
    //textcolor(27);      //color de objeto que se desplaza
    //textbackground(25); //color de rastro que deje objeto

    gotoxy(LX+j,LY+i);  //direccion en columna y fila, donde se pone el
    printf("");       //ojeto que se desplaza: carita

    c = getch();        //recibir UNA pulsacion del teclado

    x = j;       //x es la columna en pantalla, j es la columna en memoria
    y = i;       //y es la fila    en pantalla, i es la fila    en memoria

    if      ((c=='w'||c=='W')&&(i-1 != 0     && l[i-1][j] != 4)) i--;//subir
    else if ((c=='s'||c=='S')&&(i+1 != FIL+1 && l[i+1][j] != 4)) i++;//bajar
    else if ((c=='a'||c=='A')&&(j-1 != 1     && l[i][j-1] != 4)) j--;//izquierda
    else if ((c=='d'||c=='D')&&(j+1 != COL   && l[i][j+1] != 4)) j++;//derecha

    //textcolor(2);       // color del texto: verde oscuro
    gotoxy(LX+x,LY+y);  // posicion anterior (rastro)
    printf("\xDB");       // cambiar de color del rastro dejado  Û

  } while (i != FIL || j != COL-1); //falso continua, verdad termina ciclo

  //textcolor(7);
  gotoxy(35,20);
  printf("FELIICIDADES");

  return 0;
}
