/*http://www.programacion.com/foros/c-c-plus/laberinto_en_c_39821*/

#include <conio.h>
#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <stdlib.h>

using namespace std;

#define FIL  9 // cantidad de filas    del buscamina; constantes en MAYUSCULAS
#define COL 12 // cantidad de columnas del buscamina

#define LX  35 // desplazamiento coordenada x (columna) situar buscamina en pant
#define LY   7 // desplazamiento coordenada y (fila)    situar buscamina en pant
void gotoxy(short x, short y) 
{
  HANDLE cur = GetStdHandle(STD_OUTPUT_HANDLE); // Obtener handle de la consola
  COORD pos  = {x, y};                          // Crear estructura COORD con coordenadas x e y
  SetConsoleCursorPosition(cur, pos);           // Establecer posición cursor en consola
}
void hidecursor()
{
  HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
  CONSOLE_CURSOR_INFO info;
  info.dwSize   = 100;
  info.bVisible = FALSE;
  SetConsoleCursorInfo(consoleHandle, &info);
}
void showcursor()
{
  HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
  CONSOLE_CURSOR_INFO info;
  info.dwSize   = 100;
  info.bVisible = TRUE;
  SetConsoleCursorInfo(consoleHandle, &info);
}
int main(void)
{
  //textbackground(15); // color de fondo de toda la pantalla: gris
  //clrscr();
  hidecursor();
  gotoxy(30,3);   //fila 3, columna 30
  //textcolor(4);
  printf("CAMPO DE MINAS EXPLOSIVAS\n");
  gotoxy(23,4);
  printf("W=Subir A=Izquierda S=Bajar D=Derecha");

  int lab[FIL+1][COL];         // matriz buscamina EN MEMORIA INTERNA DE 10x12
  void buscamina(int l[][COL]); // funcion para dibujar buscamina EN PANTALLA
  void mover(int l[][COL]);     // moverse en el buscamina EN PANTALLA

  buscamina(lab);  //llama a dibujar el buscamina
  mover(lab);      //llama a moverse por el buscamina
  getch();         //para detener al final del programa y ver resultado
  
  showcursor();
  return 0;
}
void buscamina(int l[][COL]) //dibujo del buscamina
{
  int i, j, f, c;
  time_t t;
  srand((unsigned) time(&t));

  //textcolor(4); //color de lugar NO vacio: rojo

  for (i=1;i<=FIL;i++)     //ciclo PARA, para manejar las filas    i
    for (j=1;j<=COL;j++)   //ciclo PARA, para manejar las columnas j
     {
       l[i][j]=0;     //0: lugar vacio, donde puede desplazarse
                      //4: lugar NO vacio, donde NO puede desplazarse
       gotoxy(LX+j,LY+i);
       printf("\xB2");     //pintar todos los lugares, los libres y con minas
     }

  for (i=0; i<4; i++)     //ciclo PARA, para poner las 5 minas aleatoriamente
     {
      f = int(rand())%  9 + 1;
      c = int(rand())% 12 + 1;
      l[f][c] = 4 ; //4 signfica mina
     }
///* estos dos fores seran eliminados para no mostrar las minas  */
//  for (i=1;i<=FIL;i++)     //ciclo PARA, para manejar las filas    i
//    for (j=1;j<=COL;j++)   //ciclo PARA, para manejar las columnas j
//     {
//       gotoxy(LX+j,LY+i);
//       printf("%d",l[i][j]);
//     }
}
void mover(int l[][COL])
{
  int i=1, j=2, x=i, y=j, c, v, p=0;
  char tmpbuf[128];

  v=0; //contador de lugares visitados SIN minas, para GANAR DEBERA SER 108-5

  do
  {
    //textcolor(27);      //color de objeto que se desplaza
    //textbackground(25); //color de rastro que deje objeto

    gotoxy(LX+j,LY+i);  //direccion en columna y fila, donde se pone el
    printf("");       //ojeto que se desplaza: carita

    c = getch();        //recibir UNA pulsacion del teclado

    x = j;       //x es la columna en pantalla, j es la columna en memoria
    y = i;       //y es la fila    en pantalla, i es la fila    en memoria

    if ((c=='w'||c=='W')&&(i-1 != 0     )) i--;//subir
    if ((c=='s'||c=='S')&&(i+1 != FIL+1 )) i++;//bajar
    if ((c=='a'||c=='A')&&(j-1 != 0     )) j--;//izquierda
    if ((c=='d'||c=='D')&&(j+1 != COL+1 )) j++;//derecha

    //textcolor(2);       // color del texto: verde oscuro
    gotoxy(LX+x,LY+y);    // posicion anterior (rastro)
    printf("\xB0");          // cambiar de color del rastro dejado

    if (l[i][j]==0)
        {
          v = v + 1;
          gotoxy(32,5);
          //textbackground(15);
          printf("Lugares visitados: %d", v);
          
          // https://learn.microsoft.com/es-es/cpp/c-runtime-library/reference/time-time32-time64?view=msvc-170
          gotoxy(35,18);     
          _strtime_s(tmpbuf, 128 );
          printf( "Hora:%s\n", tmpbuf );// Display operating system-style time.
      
        }  // no piso mina, cuenta visitados
      else
        { p = 1;  }; //bandera, piso mina!!!
  } while (p == 0 || v == 8); //falso continua, verdad termina ciclo

  if (v==8)
    {
      //textcolor(7);
      gotoxy(32,17);
      printf("FELIICIDADES");
    };
  if (p==1)
    {
      //textcolor(7);
      gotoxy(32,17);
      printf("PISASTE UNA MINA!!!");
    };
}
